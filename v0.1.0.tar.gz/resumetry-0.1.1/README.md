# resumetry
template driven document generation

**Execute**
```
python main.py \
  -c templates/sample/sample.yaml \
  --template-path templates/sample/sample.tex \
  -o templates/sample/sample.pdf
```

**Design**  
[Typer](https://github.com/fastapi/typer) - CLI Framework
